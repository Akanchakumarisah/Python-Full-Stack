function square(num) {
    return num * num;
}

console.log(square(60))

const summ = (a,b) => b + a;
console.log(summ(4,3))

