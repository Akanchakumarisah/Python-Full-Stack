let day = "monday"

console.log(`Today is ${day}`)
// switch (day) {
//     case "monday":
//         console.log("monday")
//         break;
    
//     case "Friday":
//         console.log("it's firday")
//         break
//     default:
//         console.log("it's a default condition")
// }

// let age = 16
// let state = age >= 18 ? "Adult" : "Minor";
// console.log(state)

